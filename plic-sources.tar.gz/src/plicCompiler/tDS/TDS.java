package plicCompiler.tDS;

import java.util.ArrayList;

import plicCompiler.arbreAbstrait.expression.Identificateur;

public class TDS {
	
	private static TDS instance = null;

	public static int deplacementInitial = 12;
	
	private boolean analyseSyntaxique = true;
	
	private LocalDictionnary currentBlock;
	
	private int idBlock = 0;
	
	public static TDS getInstance() {
		if(TDS.instance == null)
			TDS.instance = new TDS();
		
		return instance;
	}
	
	private TDS() {
		this.currentBlock = new LocalDictionnary();
	}
	
	public void entrerBlock() {
		if(this.analyseSyntaxique){
			idBlock++;
			currentBlock = currentBlock.newChild(idBlock);
		}
		else 
			currentBlock = currentBlock.nextChild();
	}
	
	public void sortirBlock() {
		currentBlock = currentBlock.getFather();
	}
	
	public void ajouter(Identificateur e, Symbole s, int ligne) {
		currentBlock.add(e,s, ligne);
	}
	
	public void ajouter(ArrayList<Identificateur> listE, Symbole s, int ligne) {
		for(Identificateur e: listE)
			currentBlock.add(e, s.clone(), ligne);
	}
	
	public void setAnalyseSyntaxique(boolean analyseSyntaxique) {
		this.analyseSyntaxique = analyseSyntaxique;
	}
	
	public String toCode() {
		return this.currentBlock.codeEntre();
	}

	@Override
	public String toString() {
		return currentBlock.toString();
	}

	public void check() {
		this.currentBlock.checkAll();
	}

	public Symbole identifier(Identificateur identificateur) {
		return this.currentBlock.identifier(identificateur);
	}

	public LocalDictionnary getCurrentDictionnary() {
		return this.currentBlock;
	}

	public String codeEntre() {
		return this.currentBlock.codeEntre();
	}

	public String codeSortie() {
		return this.currentBlock.codeSortie();
	}

}
