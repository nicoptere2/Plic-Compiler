package plicCompiler.arbreAbstrait.instruction;

public abstract class Ecrire extends Instruction {

	public Ecrire(int ligne) {
		super(ligne);
		// TODO Auto-generated constructor stub
	}

}
