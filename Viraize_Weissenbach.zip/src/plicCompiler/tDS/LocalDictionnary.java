package plicCompiler.tDS;

public class LocalDictionnary {

}
