package plicCompiler.analyseLexSynt;

@SuppressWarnings("serial")
public class SyntaxicalException extends RuntimeException{

	public SyntaxicalException(String message) {
		super(message);
	}
}
