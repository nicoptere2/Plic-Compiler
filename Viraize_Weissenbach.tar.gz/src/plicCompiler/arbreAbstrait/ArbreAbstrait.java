package plicCompiler.arbreAbstrait;

import plicCompiler.analyseSemantique.exception.TypeIncompatibleException;

public class ArbreAbstrait {
	
	public ArbreAbstrait() {
		//TODO ecrire le constructeur ici
	}

	public String toCode(){
		return null;
		
	}

	public void checkType() throws TypeIncompatibleException {
	}
	
	
	
}
